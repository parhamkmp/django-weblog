from django.urls import include, path
from .import views



app_name='blog'
urlpatterns=[
	path('',views.index,name='index'),
	path('postlist/', views.postlist,name='post_list'),
	path('postdetail/<slug:post>/<int:pk>/', views.postdetail, name='post_detail'), # <int:year>/<int:month>/<int:day>/<slug:post>
]

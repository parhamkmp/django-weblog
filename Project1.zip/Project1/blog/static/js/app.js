const status = document.querySelector('.sts');
if(status.innerHTML == 'Status: draft')
{
	status.classList.add('bg-danger');
	status.classList.remove('bg-success');
}


else
{
	status.classList.add('bg-success');
	status.classList.remove('bg-danger');
}






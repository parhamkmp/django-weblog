# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Post
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Create your views here.


def index(request):
	return HttpResponse('<h1>Hello welcome to INDEX page:</h1>\n<a href="postlist/">Go post list page</a>')


def postlist(request):
	allPosts = Post.objects.all().filter(status='published')
	posts=Post.objects.all().filter(status='published')
	paginator = Paginator(posts, 2)
	page=request.GET.get('page')
	try:
		posts = paginator.page(page)
	except PageNotAnInteger:
		posts = paginator.page(1)

	except EmptyPage:
		posts = paginator.page(paginator.num_pages)

	return render(request, 'blog/post/list.html', {'posts':posts, 'page':page, 'postCount':allPosts.count()})


def postdetail(request, post, pk): # request, year, month, day, post
	post=get_object_or_404(Post,slug=post,id=pk) # Post, publish__year=year, publish__moth=month, publish__day=day

	return render(request, 'blog/post/detail.html', {'post':post})



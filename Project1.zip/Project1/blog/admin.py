# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import admin
from .models import Post

# Register your models here.

# admin.site.register(Post) # For register the model in the admin page 

@admin.register(Post)
class PotstAdmin(admin.ModelAdmin):
	list_display = ('title','slug','author','publish','status','short_body')
	list_filter = ('status','publish','created','author',)
	search_fields = ('title','body',)
	prepopulated_fields = {'slug':('title',)}
	raw_id_fields = ('author',)
	date_hierarchy = 'publish'
	ordering = ('status',)
	list_editable = ('status',)
	list_display_links = ('short_body',)

